# devops-demo

[![Build Status](https://drone.qikqiak.com/api/badges/cnych/devops-demo/status.svg)](https://drone.qikqiak.com/cnych/devops-demo)

drone with kubernetes demo

